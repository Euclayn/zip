<HTML>
<HEAD>
<SCRIPT LANGUAGE="JavaScript" SRC="xorcrypt12.js">
alert ("Error loading xorcrypt12.js!");
</SCRIPT>
<SCRIPT LANGUAGE="JavaScript">

function process() {
var password="";
var contents="{N5  ;~~d~a1uYg9NWDL~Q~'Q IM2jG~'~h~~yV~c8K7o7EygD~O~'0kAO7 h~HC7yR1M~'~W~~VdbjkHgp h gkyQ18JAo~~db~V~B2BS~W~~Vd~a1uYg9NWDL~Q~'Q IM2jG~PCAfN~'~h~~yVd~aHkEFiyQGBJ @~'	3FW~dKAB~'oF7Ft 	~Q~'blx2~';~~dbWy~UBKBiGgMal1~O~'FSaO~'njxF7~H~'FL7DjxF7~'LCG30SKHE1SE~O~'sqxBEnW2	O2gDgJDLCCJ SoILOP1M~'nlxOM2fA~O~'~IW~HUh~GVb~Pc~f$~h~L~Z~U\~d~Rh~GVx~PWc!W~D~D~N(~R5DB>~E~I~X~d@~f~G~Y~E<~S~b~g~G$~h~K~G~L%~f~D~N~IW~HUh~GVb~Pc~J'\~V~Py!cf~Rx4~He~O~R\~d~R3~G3n~P4c!W~Q~G\~A~C~K~N~e+~Jf~RxW~HUV~Gx~I~L~Z~U#x~PWo!yT~RV!~I~I~Po!y5~Rb4~He~O~D}\~V~M~g#x~PWo!yT~RV$~D~X~b~IW~HUh~GVb~Pc~G$~Q~R3~G3n~P4c!W~Q~M~e_~d~Yd~b?\	~X~'LGBMNS~G~'inIAO7DLzHODSzOisqxBEnW2	O2gDgJDLCCJ SoILOP1M~'nf1JLKf1	~h~~yVdb~VuAKLFLGRI2@~'K3EgXHO1~'oI3OS~G~'LESEK3EgXHO1~'oKEyQ1CJNR1M~Q~'bxLNYkE	~'nlxOM2fA~O~'~c<S~S~d~'LGBMNS~G~'kK71gJDLNHO2LzC3DWzO7Dg~'gO2mFBO2R~X~~bWyV~c  lFOiF	C9~Q~'gF8DKh~'gKyq1~O~'1WG5~'n7xGL2@~'sJILfI~'~W~~Vdb~V~BIHOO;~~dbW{2BSnQO5NE@~'L IjJIuKjL~'~h~~yVdb~VWoCO2r~G~'AFhCL~b~d~BXPR~crx77zk D~T0kN~UO2Q Q7D~BJI FuxO7~epXQ~Qd4b~J3Ol~b5OE@I592P HF~fp    ~'ogMyfH9M~H~'~e8EyjL~'~htkE JFh1IiyQzHL h~f~c~Sy;~~dbWy~ULIyj~Xg·n{~cLIyj~X~~bWyV~c3ntE9C~H~'KOMBg~V~U~SY8X~VCyQ18JAo~d7JO~BE~VIJl~fGJ0WO9~Q2j~elg~QWNK~V1uDKEy	~GK3IS~'gMyfH9M~H~'~e8EyjL~'~h6uHIiGloAJDLu592P HF~V~Bx~f~~WyV~c~S1uY~f~~Wy~U~U8K7~X~~b~V~B2BS~W~~~U~UDyuA~f";

password=prompt("Enter the password to decode this document", "");
if (password!=null)
	{
	document.write(decrypt(contents, password));
	document.close();
	}
}
</SCRIPT>
</HEAD>
<BODY onLoad="process()">
</BODY>
</HTML>