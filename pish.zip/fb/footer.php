<footer>
		<div class="container pageFooter">
			<ul class="langs">
				<li>English (UK)</li>

				<li>
					<a href="#">
						اردو
					</a>
				</li>

				<li>
					<a href="#">
						پښتو
					</a>
				</li>

				<li>
					<a href="#">
						العربية
					</a>
				</li>

				<li>
					<a href="#">
						हिन्दी
					</a>
				</li>

				<li>
					<a href="#">
						বাংলা
					</a>
				</li>

				<li>
					<a href="#">
						ਪੰਜਾਬੀ
					</a>
				</li>

				<li>
					<a href="#">
						فارسی
					</a>
				</li>

				<li>
					<a href="#">
						ગુજરાતી
					</a>
				</li>

				<li>
					<a href="#">
						Deutsch
					</a>
				</li>

				<li>
					<a href="#">
						Español
					</a>
				</li>
			</ul>
			<div id="contentCurve"></div>

			<ul class="otherLinks">
				<li><a href="#">Sign Up</a></li>
				<li><a href="#">Log In</a></li>
				<li><a href="#">Messenger</a></li>
				<li><a href="#">Facebook Lite</a></li>
				<li><a href="#">Mobile</a></li>
				<li><a href="#">Find Friends</a></li>
				<li><a href="#">People</a></li>
				<li><a href="#">Pages</a></li>
				<li><a href="#">Video interests</a></li>
				<li><a href="#">Places</a></li>
				<li><a href="#">Games</a></li>
				<li><a href="#">Locations</a></li>
				<li><a href="#">Marketplace</a></li>
				<li><a href="#">Groups</a></li>
				<li><a href="#">Instagram</a></li>
				<li><a href="#">Local</a></li>
				<li><a href="#">About</a></li>
				<li><a href="#">Create ad</a></li>
				<li><a href="#">Create Page</a></li>
				<li><a href="#">Developers</a></li>
				<li><a href="#">Careers</a></li>
				<li><a href="#">Privacy</a></li>
				<li><a href="#">Cookies</a></li>
				<li><a href="#">AdChoices</a></li>
				<li><a href="#">Terms</a></li>
				<li><a href="#">Help</a></li>
			</ul>

			<div id="copyright">
				Facebook &copy; 2018
			</div>
		</div>
	</footer>

</body>
</html>